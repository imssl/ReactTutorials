import './App.css';
import MasterPage from './MasterPage.jsx';


function App() {
  return (
    <div className="App">
      <MasterPage />
    </div>
  );
}

export default App;
